package com.example.myapp.controller;

import com.example.myapp.service.TextProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
public class TextController {

    private final TextProcessingService textProcessingService;

    @Autowired
    public TextController(TextProcessingService textProcessingService) {
        this.textProcessingService = textProcessingService;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @PostMapping("/hello")
    @ResponseBody
    public String hello() {
        return "Built In Demo...!!";
    }

    @PostMapping("/process-text")
    @ResponseBody
    public String processText(@RequestBody Map<String, String> request) {
        String text = request.get("text");
        return textProcessingService.processText(text);
    }

    @PostMapping("/analyze-number")
    @ResponseBody
    public String analyzeNumber(@RequestBody Map<String, Integer> request) {
        int number = request.get("number");
        return textProcessingService.analyzeNumber(number);
    }
}