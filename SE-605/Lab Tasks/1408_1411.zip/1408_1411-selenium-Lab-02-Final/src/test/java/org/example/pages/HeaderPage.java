package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HeaderPage extends BasePage {
    private final By signOutButton = By.id("signout");

    public HeaderPage(WebDriver driver) {
        super(driver);
    }

    public void signOut() {
        click(signOutButton);
    }
}