package org.example.tests;

import org.example.pages.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.Scanner;

public class UnifiedTestSuite {
    private static WebDriver driver;
    private static SignInPage signInPage;
    private static SignUpPage signUpPage;
    private static HeaderPage headerPage;
    private static BoardPage boardPage;
    private static BoardListPage boardListPage;
    private static ListPage listPage;
    private static CardPage cardPage;
    private static CommentPage commentPage;
    private static BoardMemberPage boardMemberPage;

    @BeforeClass
    public static void setUp() {
        driver = new FirefoxDriver();
        driver.manage().window().setSize(new Dimension(1024, 768));

        signInPage = new SignInPage(driver);
        signUpPage = new SignUpPage(driver);
        headerPage = new HeaderPage(driver);
        boardPage = new BoardPage(driver);
        boardListPage = new BoardListPage(driver);
        listPage = new ListPage(driver);
        cardPage = new CardPage(driver);
        commentPage = new CommentPage(driver);
        boardMemberPage = new BoardMemberPage(driver);
    }

    @Test
    public void fullWorkflowTest() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        signInPage.open("http://localhost:4000/sign_in");
        signInPage.signIn(email, password);

        boardPage.clickAddNewBoard();
        boardPage.createBoard("Project Board");

        boardListPage.openFirstBoard();
        listPage.createList("To Do");
        listPage.updateList("In Progress");

        cardPage.createCard("Sample Card");
        cardPage.updateCard("Updated Card");
        cardPage.tagCard("Urgent");
        commentPage.addComment("This task needs review.");
        boardMemberPage.addMember("newmember@example.com");
        cardPage.cancelCardCreation();
        cardPage.deleteCard();

        headerPage.signOut();
    }

    @AfterClass
    public static void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}