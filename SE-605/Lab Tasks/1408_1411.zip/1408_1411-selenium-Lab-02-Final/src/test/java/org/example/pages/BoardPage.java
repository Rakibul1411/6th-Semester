package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BoardPage extends BasePage {
    private final By addNewBoardButton = By.id("add-board");
    private final By boardNameInput = By.id("board-name");
    private final By createButton = By.cssSelector("button.create");

    public BoardPage(WebDriver driver) {
        super(driver);
    }

    public void clickAddNewBoard() {
        click(addNewBoardButton);
    }

    public void createBoard(String boardName) {
        type(boardNameInput, boardName);
        click(createButton);
    }
}