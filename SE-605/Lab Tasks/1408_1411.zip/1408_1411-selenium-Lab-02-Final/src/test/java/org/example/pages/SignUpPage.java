package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignUpPage extends BasePage {
    private final By nameField = By.id("name");
    private final By emailField = By.id("email");
    private final By passwordField = By.id("password");
    private final By registerButton = By.cssSelector("button");

    public SignUpPage(WebDriver driver) {
        super(driver);
    }

    public void register(String name, String email, String password) {
        type(nameField, name);
        type(emailField, email);
        type(passwordField, password);
        click(registerButton);
    }
}