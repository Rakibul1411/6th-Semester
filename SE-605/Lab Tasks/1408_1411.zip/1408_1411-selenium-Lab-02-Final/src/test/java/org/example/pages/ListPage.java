package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ListPage extends BasePage {
    private final By newListInput = By.id("list-name");
    private final By createListButton = By.cssSelector("button.create-list");
    private final By updateListInput = By.id("update-list-name");

    public ListPage(WebDriver driver) {
        super(driver);
    }

    public void createList(String listName) {
        type(newListInput, listName);
        click(createListButton);
    }

    public void updateList(String updatedName) {
        type(updateListInput, updatedName);
        click(createListButton);
    }
}