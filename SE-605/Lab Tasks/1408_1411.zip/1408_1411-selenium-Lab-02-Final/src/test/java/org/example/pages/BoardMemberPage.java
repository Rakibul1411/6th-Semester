package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BoardMemberPage extends BasePage {
    private final By memberEmailInput = By.id("member-email");
    private final By addMemberButton = By.cssSelector("button.add-member");

    public BoardMemberPage(WebDriver driver) {
        super(driver);
    }

    public void addMember(String email) {
        type(memberEmailInput, email);
        click(addMemberButton);
    }
}