package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CardPage extends BasePage {
    private final By newCardInput = By.id("card-name");
    private final By createCardButton = By.cssSelector("button.create-card");
    private final By cancelButton = By.cssSelector("button.cancel");
    private final By updateCardInput = By.id("update-card-name");
    private final By deleteCardButton = By.id("delete-card");
    private final By tagInput = By.id("tag-input");
    private final By tagButton = By.cssSelector("button.add-tag");

    public CardPage(WebDriver driver) {
        super(driver);
    }

    public void createCard(String cardName) {
        type(newCardInput, cardName);
        click(createCardButton);
    }

    public void cancelCardCreation() {
        click(cancelButton);
    }

    public void updateCard(String updatedName) {
        type(updateCardInput, updatedName);
        click(createCardButton);
    }

    public void deleteCard() {
        click(deleteCardButton);
    }

    public void tagCard(String tag) {
        type(tagInput, tag);
        click(tagButton);
    }
}