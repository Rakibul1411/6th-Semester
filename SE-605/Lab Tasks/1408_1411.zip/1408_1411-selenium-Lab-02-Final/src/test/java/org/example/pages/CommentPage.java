package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CommentPage extends BasePage {
    private final By commentInput = By.id("comment-input");
    private final By addCommentButton = By.cssSelector("button.add-comment");

    public CommentPage(WebDriver driver) {
        super(driver);
    }

    public void addComment(String comment) {
        type(commentInput, comment);
        click(addCommentButton);
    }
}