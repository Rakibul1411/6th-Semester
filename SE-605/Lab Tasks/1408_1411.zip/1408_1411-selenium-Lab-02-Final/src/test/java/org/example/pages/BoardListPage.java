package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BoardListPage extends BasePage {
    private final By firstBoard = By.cssSelector(".board-list .board-item:first-child");

    public BoardListPage(WebDriver driver) {
        super(driver);
    }

    public void openFirstBoard() {
        click(firstBoard);
    }
}
