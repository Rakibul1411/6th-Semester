import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;



public class Client {
    public static void main(String[] args) {
        try {
//            String host = "103.221.253.161";
            String host = "10.100.200.104";
            Registry registry = LocateRegistry.getRegistry(host, 1099);

            RemoteInterface stub = (RemoteInterface) registry.lookup("HelloService");
            String response = stub.sayHello("Client");
            System.out.println("Response from server: " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
